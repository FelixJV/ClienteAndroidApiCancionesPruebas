package com.example.composefotosappfjv.domain.modelo


data class Cancion(
    var id: Int,
    var nombre: String,
    var artista: String
)
package com.example.composefotosappfjv.domain.modelo

data class User(
    var nombre: String = "",
    var pass: String ="",
    var verificado: Boolean = false,
    var emal:String = "",
)
